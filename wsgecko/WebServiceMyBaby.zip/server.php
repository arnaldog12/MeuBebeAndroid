<?php

include 'Classes/Conexao.php';

if (isset($_GET['data'])) {
    $data = $_GET['data'];
    
    $conexao = new Conexao();
    $retorno = $conexao->listar('dicas_usuarios', "nome,dica,categoria", "WHERE data > '" . $data . "'");
    $arg = array();
    count($retorno);
    
    for ($i = 0; $i < count($retorno); $i++) {
        $arg = $retorno[$i];
    //    echo $arg['email'] . " ";
     //   echo $arg['nome'] . " ";
     //   echo $arg['categoria'] . " <br>";
    }
    
    $saida2 = $conexao->listar('dicas_usuarios', "MAX(data) as maior_Data", " ");
    //echo $i;
    //echo $retorno[$i];
    $retorno[$i] = $saida2[0];
    
    echo json_encode($retorno);
  //  echo "<br>E: ".$retorno[$i]['max']."<br>";
    /* 
   for($i=0; $i < count($retorno)-1; $i++){
       $arg=$retorno[$i];
        echo $arg['email'] . " ";
        echo $arg['nome'] . " ";
        echo $arg['categoria'] . " <br>";
   }*/
   
    //echo "<br>E: ".$retorno[$i]['max']."<br>";
   
    
} else {
    echo 'Nao Existe';
}
//echo $hora;
/*    if ($data == '01/21/2013') {
  $me = array(
  'nome' => 'Arnaldo',
  'email' => 'arnaldo.g12@gmail.com',
  'dica' => 'Ao completar 6 meses, introduzir de forma lenta e gradual outros alimentos, mantendo o leite materno ate os dois anos de idade ou mais.',
  'categoria' => 'Alimentação',
  // 'maior_data' => '20/01/2013'
  );
  echo json_encode($me);
  }else
  echo 'Hello, World!'; */



?>
