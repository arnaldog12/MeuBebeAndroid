--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dicas_usuarios; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE dicas_usuarios (
    id integer NOT NULL,
    email character varying(60),
    nome character varying(80),
    dica text,
    categoria character varying(20),
    data timestamp without time zone
);


ALTER TABLE public.dicas_usuarios OWNER TO postgres;

--
-- Name: dicas_usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE dicas_usuarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.dicas_usuarios_id_seq OWNER TO postgres;

--
-- Name: dicas_usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE dicas_usuarios_id_seq OWNED BY dicas_usuarios.id;


--
-- Name: dicas_usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('dicas_usuarios_id_seq', 8, true);


--
-- Name: teste; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE teste (
    nome character varying(50),
    email character varying(50),
    dica text,
    categoria character varying(30),
    data text
);


ALTER TABLE public.teste OWNER TO postgres;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY dicas_usuarios ALTER COLUMN id SET DEFAULT nextval('dicas_usuarios_id_seq'::regclass);


--
-- Data for Name: dicas_usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dicas_usuarios (id, email, nome, dica, categoria, data) FROM stdin;
5	arnaldo@gmail.com	Arnaldo	Ao completar 7 meses	dorgas	2013-01-20 10:36:38
7	glauco@gmail.com	Glauco	Ao completar 9 meses	dorgas e dorgas	2013-01-20 12:36:38
8	yyurigil@gmail.com	Yuri Gil Dantas	Ao completar 6 meses	Alimentação	2013-01-17 10:36:38
9	hugoneves@gmail.com	Hugo Neves	Ao terminar o ... 	Nothing	2013-01-28 22:00:00
10	xaxa@gmail.com	eu	Ao terminar o pc 	sHIT	2013-01-29 22:00:00
\.


--
-- Data for Name: teste; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY teste (nome, email, dica, categoria, data) FROM stdin;
\.


--
-- Name: dicas_usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY dicas_usuarios
    ADD CONSTRAINT dicas_usuarios_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

